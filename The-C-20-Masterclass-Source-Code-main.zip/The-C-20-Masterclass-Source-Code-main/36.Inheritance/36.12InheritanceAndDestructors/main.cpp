#include <iostream>
#include "person.h"
#include "engineer.h"
#include "civilengineer.h"

int main(){
   
	CivilEngineer eng1("Daniel Gray",41,"Green Sky Oh Blue 33St#75",12,"Road Strength");

    return 0;
}