#include "cylinder.h"

namespace Geom{
    
    Cylinder::Cylinder(double base_rad, double height)
        : m_base_rad{base_rad} , m_height{height}
    {
    }
    
}



